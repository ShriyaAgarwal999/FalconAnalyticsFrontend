import {OnInit } from '@angular/core';

export class TestReportPassPercent{

public passPercent: Array<number>;
public runSessionId: Array<number>;

  constructor(passPercent: Array<Number> , runSessionId: Array<Number>){
this.passPercent = Object.assign([], passPercent);
this.runSessionId = Object.assign([], runSessionId);
  }

  ngOnInit() {

}
}
