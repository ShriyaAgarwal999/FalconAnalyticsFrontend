import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { TestReportService } from '../services/testReport.services';
import { TestReportPassPercent } from '../models/testReportPassPercent.model';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-falcon-analytics',
  templateUrl: './falcon-analytics.component.html',
  styleUrls: ['./falcon-analytics.component.css']
})
export class FalconAnalyticsComponent implements OnInit {
report= TestReportPassPercent;
    showBar = "hidden";
    showPie = "hidden";
    showDiv: boolean = false;

    showBarChart() {
    this.showBar = null;
    this.showPie = "hidden";
    }
    showPieChart() {
    this.showPie = null;
    this.showBar = "hidden";
    }

    @ViewChild('productName') productRef: ElementRef;


    public chartType1 =environment.chartType1;
    public barChartOptions = {
    scaleShowVerticalLines: false,
    scales: {
    yAxes: [{
    scaleLabel: {
    display: true,
    labelString: 'Test Pass Percentage',
    fontSize:16,
    }
    }],
    xAxes: [{
    scaleLabel: {
    display: true,
    labelString: 'Run Session ID',
    fontSize:16,
    }
    }]
    }
    };

    public chartType2=environment.chartType2;
    public pieChartOptions = {
    responsive: true,
    title: {
    display: true,
    text: 'Test Pass Percentage of last runs',
    fontSize:18,
    }};

  constructor(private reportService:TestReportService) {

  }

  ngOnInit() {
  }

/*function to subscribe to the database to retrieve required data*/
  submitProductName(){
    const product=this.productRef.nativeElement.value;
    this.reportService.getTestPassPercent(product)
        .subscribe( data => {
          this.report = data;
          console.log(this.report);
        });

  }

}
