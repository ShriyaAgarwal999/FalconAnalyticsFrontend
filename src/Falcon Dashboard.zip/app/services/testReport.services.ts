import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { TestReportPassPercent } from '../models/testReportPassPercent.model';

const httpOptions = {
headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class TestReportService {

  constructor(private http:HttpClient) { }


/*http request to get data from database using springBoot*/
   public getTestPassPercent(product:string) {
    return this.http.get<TestReportPassPercent>(environment.baseUrl+'/testReport/getDetails?productName='+product);
  }

}
